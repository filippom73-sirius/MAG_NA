import { IncomingMessage } from "http";
import { Duplex } from "stream";
import { Server } from "net";
import { WebSocket, WebSocketServer } from "ws";
import { logger } from "./lib/logger";

const encoderClients = new Set<WebSocket>();
const magnaClients = new Set<WebSocket>();

function broadcastStatus() {
  const msg = JSON.stringify({
    type: "status",
    encoders: encoderClients.size,
    magnas: magnaClients.size,
  });
  for (const c of [...encoderClients, ...magnaClients]) {
    if (c.readyState === WebSocket.OPEN) c.send(msg);
  }
}

export function setupSyncWebSocket(server: Server) {
  const wss = new WebSocketServer({ noServer: true });

  server.on("upgrade", (req: IncomingMessage, socket: Duplex, head: Buffer) => {
    const url = new URL(req.url ?? "/", "http://localhost");
    if (url.pathname !== "/api/sync") {
      socket.destroy();
      return;
    }
    wss.handleUpgrade(req, socket, head, (ws) => {
      wss.emit("connection", ws, req);
    });
  });

  wss.on("connection", (ws: WebSocket, req: IncomingMessage) => {
    const url = new URL(req.url ?? "/", "http://localhost");
    const role = url.searchParams.get("role") ?? "encoder";

    if (role === "magna") {
      magnaClients.add(ws);
      logger.info({ magnas: magnaClients.size }, "sync: MAGNA client connected");
    } else {
      encoderClients.add(ws);
      logger.info({ encoders: encoderClients.size }, "sync: encoder client connected");

      ws.on("message", (data: Buffer) => {
        const msg = data.toString();
        for (const client of magnaClients) {
          if (client.readyState === WebSocket.OPEN) client.send(msg);
        }
      });
    }

    broadcastStatus();

    ws.on("close", () => {
      encoderClients.delete(ws);
      magnaClients.delete(ws);
      broadcastStatus();
      logger.info(
        { encoders: encoderClients.size, magnas: magnaClients.size },
        "sync: client disconnected"
      );
    });
  });

  logger.info("sync: WebSocket relay ready at /api/sync");
}
