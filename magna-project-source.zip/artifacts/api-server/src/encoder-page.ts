export const ENCODER_PAGE_HTML = `<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no,viewport-fit=cover">
<title>MAG.NA Encoder Ottico</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{width:100%;height:100%;background:#020617;color:#f8fafc;font-family:system-ui,sans-serif;overflow:hidden;touch-action:manipulation}
#cam{position:fixed;top:0;left:0;width:100%;height:100%;object-fit:cover;z-index:1}
#cnv{display:none}

/* Status bar */
#statusBar{position:fixed;top:0;left:0;right:0;background:rgba(2,6,23,0.85);padding:12px 14px;padding-top:max(12px,env(safe-area-inset-top));display:flex;align-items:center;gap:10px;z-index:20;backdrop-filter:blur(4px)}
#connDot{width:10px;height:10px;border-radius:50%;flex-shrink:0;transition:background 0.3s}
#statusText{flex:1;font-size:11px;color:#94a3b8;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.chip{background:rgba(15,23,42,0.9);border:1px solid #1e293b;border-radius:8px;padding:4px 10px;text-align:center;flex-shrink:0}
.chip-label{font-size:7px;font-weight:800;color:#475569;letter-spacing:0.5px;text-transform:uppercase}
.chip-val{font-size:15px;font-weight:800;font-family:monospace;color:#f8fafc}

/* ROI overlay */
#roiBox{position:fixed;border:2px solid #f59e0b;border-radius:6px;pointer-events:none;z-index:10;transition:border-color 0.3s}
#roiCrossH,#roiCrossV{position:fixed;background:rgba(251,191,36,0.35);pointer-events:none;z-index:9}
#roiLabel{position:fixed;color:#fbbf24;font-size:9px;font-weight:800;background:rgba(0,0,0,0.6);padding:2px 7px;border-radius:4px;pointer-events:none;z-index:11;transition:color 0.3s}

/* Brightness gauge */
#briGauge{position:fixed;right:12px;top:50%;transform:translateY(-50%);display:flex;flex-direction:column;align-items:center;gap:4px;z-index:20}
#briLbl{font-size:8px;font-weight:800;color:rgba(255,255,255,0.5);letter-spacing:1px}
#briTrack{width:18px;height:100px;background:rgba(30,41,59,0.8);border-radius:6px;overflow:hidden;display:flex;flex-direction:column;justify-content:flex-end}
#briFill{width:100%;border-radius:6px;min-height:3px;transition:height 0.1s,background 0.1s}
#briNum{font-size:12px;font-weight:800;font-family:monospace;transition:color 0.1s}

/* Bottom panel */
#panel{position:fixed;bottom:0;left:0;right:0;background:rgba(2,6,23,0.88);padding:16px 18px;padding-bottom:max(20px,env(safe-area-inset-bottom));z-index:20;display:flex;flex-direction:column;gap:10px;backdrop-filter:blur(4px)}
#calibMsg{text-align:center;font-size:11px;color:#64748b;font-style:italic;line-height:1.4}
#btns{display:flex;gap:8px;align-items:stretch}
.btn{flex:1;border-radius:12px;font-size:13px;font-weight:800;padding:13px 6px;cursor:pointer;border:1px solid;transition:opacity 0.2s}
.btn:disabled{opacity:0.3;cursor:default}
#bDark{background:#1e293b;border-color:#64748b;color:#cbd5e1}
#bWhite{background:#172554;border-color:#3b82f6;color:#93c5fd}
#bMarker{background:#450a0a;border-color:#dc2626;color:#fca5a5}
#bReset{flex:0 0 auto;background:#0f172a;border-color:#334155;color:#ef4444;padding:13px 12px;border-radius:10px;font-size:11px;font-weight:700;cursor:pointer;border:1px solid #334155}
#readyBadge{background:#052e16;border:1px solid #166534;border-radius:10px;padding:10px 14px;text-align:center;color:#4ade80;font-size:12px;font-weight:700;display:none}
</style>
</head>
<body>
<video id="cam" autoplay playsinline muted></video>
<canvas id="cnv"></canvas>

<div id="statusBar">
  <div id="connDot" style="background:#475569"></div>
  <div id="statusText">Connessione al server...</div>
  <div class="chip"><div class="chip-label">Impulsi</div><div class="chip-val" id="pDisp">0</div></div>
  <div class="chip"><div class="chip-label">RPM</div><div class="chip-val" id="rDisp" style="color:#22c55e">--.-</div></div>
</div>

<div id="roiBox"></div>
<div id="roiCrossH"></div>
<div id="roiCrossV"></div>
<div id="roiLabel">ROI</div>

<div id="briGauge">
  <div id="briLbl">LUM</div>
  <div id="briTrack"><div id="briFill" style="height:0%;background:#ef4444"></div></div>
  <div id="briNum" style="color:#ef4444">0</div>
</div>

<div id="panel">
  <div id="calibMsg">Passo 1 — punta la fotocamera sulla <b>lamiera scura</b> e premi SCURO</div>
  <div id="btns">
    <button class="btn" id="bDark"  onclick="calibDark()">&#9632; SCURO</button>
    <button class="btn" id="bWhite" onclick="calibWhite()" disabled>&#9633; BIANCO</button>
    <button class="btn" id="bMarker" onclick="calibMarker()" disabled>&#128308; MARKER 0</button>
    <button id="bReset" onclick="doReset()">Reset</button>
  </div>
  <div id="readyBadge">&#10003; Pronto — rilevamento attivo</div>
</div>

<script>
var darkBri=null,whiteBri=null,markerRGB=null,step=0;
var lastBin='dark',lastPulseTs=0,lastZeroTs=0,pCount=0,pTimes=[];
var bri=0,W=8,ROI=0.18;
var vw=640,vh=480;

// WebSocket
var ws=null;
var proto=location.protocol==='https:'?'wss:':'ws:';
var wsUrl=proto+'//'+location.host+'/api/sync?role=encoder';
function connect(){
  try{
    ws=new WebSocket(wsUrl);
    ws.onopen=function(){dot('#22c55e');txt('Connesso — in attesa di MAGNA')};
    ws.onclose=function(){dot('#ef4444');txt('Disconnesso — riconnessione...');setTimeout(connect,2000)};
    ws.onerror=function(){dot('#f59e0b');txt('Errore connessione')};
    ws.onmessage=function(e){
      try{var m=JSON.parse(e.data);
        if(m.type==='status') txt(m.magnas>0?'\\u2713 MAGNA connessa ('+m.magnas+') — encoder attivo':'Connesso — in attesa di MAGNA');
      }catch(x){}
    };
  }catch(x){setTimeout(connect,3000)}
}
function dot(c){document.getElementById('connDot').style.background=c}
function txt(s){document.getElementById('statusText').textContent=s}
function send(msg){if(ws&&ws.readyState===1)ws.send(JSON.stringify(msg))}

// Camera
async function initCam(){
  try{
    var s=await navigator.mediaDevices.getUserMedia({video:{facingMode:'environment',width:{ideal:640},height:{ideal:480}}});
    var v=document.getElementById('cam');
    v.srcObject=s;
    await v.play();
    var c=document.getElementById('cnv');
    vw=v.videoWidth||640; vh=v.videoHeight||480;
    c.width=vw; c.height=vh;
    layoutROI();
    setInterval(function(){frame(v,c)},100);
  }catch(e){
    document.getElementById('calibMsg').innerHTML='&#9888; Permesso fotocamera negato — ricarica e autorizza';
  }
}

function layoutROI(){
  var sw=window.innerWidth,sh=window.innerHeight;
  var rw=sw*ROI,rh=sh*ROI;
  var rx=(sw-rw)/2,ry=(sh-rh)/2;
  var b=document.getElementById('roiBox');
  b.style.cssText='left:'+rx+'px;top:'+ry+'px;width:'+rw+'px;height:'+rh+'px';
  var cx=sw/2,cy=sh/2;
  var h=document.getElementById('roiCrossH');
  h.style.cssText='left:0;top:'+(cy-0.5)+'px;width:'+sw+'px;height:1px';
  var vv=document.getElementById('roiCrossV');
  vv.style.cssText='left:'+(cx-0.5)+'px;top:0;width:1px;height:'+sh+'px';
  var l=document.getElementById('roiLabel');
  l.style.cssText='left:'+(rx+5)+'px;top:'+(ry+5)+'px';
}

// Frame processing
function frame(v,c){
  var ctx=c.getContext('2d',{willReadFrequently:true});
  ctx.drawImage(v,0,0,vw,vh);
  var rw=Math.round(vw*ROI),rh=Math.round(vh*ROI);
  var rx=Math.round((vw-rw)/2),ry=Math.round((vh-rh)/2);
  var d=ctx.getImageData(rx,ry,rw,rh).data;
  var r=0,g=0,b=0,n=d.length/4;
  for(var i=0;i<d.length;i+=4){r+=d[i];g+=d[i+1];b+=d[i+2]}
  r/=n;g/=n;b/=n;
  bri=Math.round(0.299*r+0.587*g+0.114*b);
  updateGauge();
  if(step<2)return;
  var thr=(darkBri+whiteBri)/2;
  var now=Date.now();

  // Zero marker check (priority)
  if(step>=3&&markerRGB){
    var dr=r-markerRGB.r,dg=g-markerRGB.g,db=b-markerRGB.b;
    var dist=Math.sqrt(dr*dr+dg*dg+db*db);
    if(dist<45&&now-lastZeroTs>400){
      lastZeroTs=now;
      send({type:'zero',ts:now});
      lastBin='dark';
      return;
    }
  }

  // White window detection (rising edge)
  var cur=bri>thr?'bright':'dark';
  if(cur==='bright'&&lastBin==='dark'&&now-lastPulseTs>80){
    lastPulseTs=now;
    pCount++;
    pTimes.push(now);
    if(pTimes.length>W+1)pTimes.shift();
    var rpm=null;
    if(pTimes.length>=2){
      var ivs=[];
      for(var j=1;j<pTimes.length;j++)ivs.push(pTimes[j]-pTimes[j-1]);
      var avg=ivs.reduce(function(a,b){return a+b},0)/ivs.length;
      if(avg>0)rpm=(60000/(W*avg)).toFixed(2);
    }
    document.getElementById('pDisp').textContent=pCount;
    document.getElementById('rDisp').textContent=rpm||'--.-';
    send({type:'pulse',ts:now,idx:pCount,rpm:rpm?parseFloat(rpm):null});
  }
  lastBin=cur;
}

function updateGauge(){
  var pct=bri/255;
  var col=bri<85?'#ef4444':bri<170?'#f59e0b':'#22c55e';
  document.getElementById('briFill').style.height=Math.round(pct*100)+'%';
  document.getElementById('briFill').style.background=col;
  document.getElementById('briNum').textContent=bri;
  document.getElementById('briNum').style.color=col;
}

// Calibration
function calibDark(){
  darkBri=bri; step=1;
  document.getElementById('bWhite').disabled=false;
  document.getElementById('calibMsg').innerHTML='Passo 2 — punta sulla <b>finestra bianca</b> e premi BIANCO';
  setRoiColor('#f59e0b');
}
function calibWhite(){
  whiteBri=bri; step=2;
  document.getElementById('bMarker').disabled=false;
  document.getElementById('calibMsg').innerHTML='Passo 3 (opzionale) — punta sul <b>marker zero</b> colorato e premi MARKER 0, oppure salta';
  setRoiColor('#22c55e');
  showReady();
}
function calibMarker(){
  // Capture ROI color from canvas
  var c=document.getElementById('cnv');
  var ctx=c.getContext('2d',{willReadFrequently:true});
  var v=document.getElementById('cam');
  ctx.drawImage(v,0,0,vw,vh);
  var rw=Math.round(vw*ROI),rh=Math.round(vh*ROI);
  var rx=Math.round((vw-rw)/2),ry=Math.round((vh-rh)/2);
  var d=ctx.getImageData(rx,ry,rw,rh).data;
  var r=0,g=0,b=0,n=d.length/4;
  for(var i=0;i<d.length;i+=4){r+=d[i];g+=d[i+1];b+=d[i+2]}
  markerRGB={r:r/n,g:g/n,b:b/n}; step=3;
  document.getElementById('calibMsg').innerHTML='&#10003; Marker zero calibrato — rilevamento attivo';
  setRoiColor('#a855f7');
  showReady();
}
function showReady(){
  document.getElementById('readyBadge').style.display='block';
  document.getElementById('calibMsg').style.display='none';
}
function doReset(){
  darkBri=null;whiteBri=null;markerRGB=null;step=0;
  lastBin='dark';lastPulseTs=0;lastZeroTs=0;pCount=0;pTimes=[];
  document.getElementById('bWhite').disabled=true;
  document.getElementById('bMarker').disabled=true;
  document.getElementById('readyBadge').style.display='none';
  document.getElementById('calibMsg').style.display='block';
  document.getElementById('calibMsg').innerHTML='Passo 1 — punta la fotocamera sulla <b>lamiera scura</b> e premi SCURO';
  document.getElementById('pDisp').textContent='0';
  document.getElementById('rDisp').textContent='--.-';
  setRoiColor('#f59e0b');
}
function setRoiColor(c){
  document.getElementById('roiBox').style.borderColor=c;
  document.getElementById('roiLabel').style.color=c;
}

connect();
initCam();
window.addEventListener('resize',layoutROI);
</script>
</body>
</html>`;
