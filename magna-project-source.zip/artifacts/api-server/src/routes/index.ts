import { Router, type IRouter } from "express";
import healthRouter from "./health";
import { ENCODER_PAGE_HTML } from "../encoder-page";

const router: IRouter = Router();

router.use(healthRouter);

router.get("/encoder", (_req, res) => {
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.setHeader("Cache-Control", "no-store");
  res.send(ENCODER_PAGE_HTML);
});

export default router;
