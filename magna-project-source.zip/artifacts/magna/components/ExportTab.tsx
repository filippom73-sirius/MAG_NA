import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";

import { useApp } from "@/context/AppContext";

export function ExportTab() {
  const { sessions, clearHistory, exportToCSV, paccoHeight, activeSteps } = useApp();

  return (
    <View style={styles.container}>
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Riepilogo Sessioni</Text>
        <View style={styles.headerRow}>
          <Text style={[styles.col, styles.colHeader]}>Quota Z</Text>
          <Text style={[styles.col, styles.colHeader]}>Punti</Text>
          <Text style={[styles.col, styles.colHeader]}>Max X</Text>
          <Text style={[styles.col, styles.colHeader]}>Min X</Text>
        </View>
        {sessions.length === 0 ? (
          <View style={styles.empty}>
            <Text style={styles.emptyText}>Nessuna sessione acquisita</Text>
            <Text style={styles.emptySubText}>Avvia una misura per raccogliere i dati</Text>
          </View>
        ) : (
          sessions
            .sort((a, b) => a.z - b.z)
            .map((sess, i) => {
              const xs = sess.data.map((d) => d.x);
              const maxX = Math.max(...xs);
              const minX = Math.min(...xs);
              return (
                <View key={i} style={[styles.dataRow, i % 2 === 0 && styles.dataRowAlt]}>
                  <Text style={[styles.col, styles.colData]}>{sess.z} mm</Text>
                  <Text style={[styles.col, styles.colData]}>{sess.data.length}</Text>
                  <Text style={[styles.col, { color: "#ef4444", fontSize: 11, fontFamily: "monospace", flex: 1 }]}>{maxX.toFixed(0)}</Text>
                  <Text style={[styles.col, { color: "#3b82f6", fontSize: 11, fontFamily: "monospace", flex: 1 }]}>{minX.toFixed(0)}</Text>
                </View>
              );
            })
        )}
      </View>

      <View style={styles.statusCard}>
        <Text style={styles.statusLabel}>Avanzamento Mappatura</Text>
        <Text style={styles.statusValue}>
          {sessions.length} / {activeSteps.length} livelli
        </Text>
        <Text style={[styles.statusBadge, sessions.length === activeSteps.length && activeSteps.length > 0 ? styles.badgeComplete : styles.badgeIncomplete]}>
          {sessions.length === activeSteps.length && activeSteps.length > 0 ? "COMPLETO" : "INCOMPLETO"}
        </Text>
      </View>

      <View style={styles.actionRow}>
        <Pressable
          style={[styles.btn, styles.btnPrimary, sessions.length === 0 && styles.btnDisabled]}
          onPress={exportToCSV}
          disabled={sessions.length === 0}
        >
          <Text style={styles.btnText}>Esporta CSV</Text>
        </Pressable>
        <Pressable
          style={[styles.btn, styles.btnDanger, sessions.length === 0 && styles.btnDisabled]}
          onPress={clearHistory}
          disabled={sessions.length === 0}
        >
          <Text style={styles.btnText}>Cancella Dati</Text>
        </Pressable>
      </View>

      <View style={styles.infoCard}>
        <Text style={styles.infoTitle}>Formato CSV</Text>
        <Text style={styles.infoText}>
          Il file esportato contiene:{"\n"}
          • Altezza Pacco (mm){"\n"}
          • Quota Z (mm){"\n"}
          • Angolo (0–359°){"\n"}
          • Flusso X, Y, Z (µT)
        </Text>
        <Text style={styles.infoText}>
          Modello: H{paccoHeight} | {activeSteps.length} livelli Z
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { gap: 12 },
  section: { backgroundColor: "#1e293b", borderRadius: 12, overflow: "hidden", borderWidth: 1, borderColor: "#334155" },
  sectionTitle: { color: "#94a3b8", fontSize: 10, fontWeight: "700", textTransform: "uppercase", letterSpacing: 1, padding: 10, borderBottomWidth: 1, borderBottomColor: "#334155" },
  headerRow: { flexDirection: "row", paddingHorizontal: 10, paddingVertical: 6, backgroundColor: "#0f172a" },
  col: { flex: 1 },
  colHeader: { color: "#64748b", fontSize: 9, fontWeight: "700", fontFamily: "monospace", textTransform: "uppercase" },
  dataRow: { flexDirection: "row", paddingHorizontal: 10, paddingVertical: 8 },
  dataRowAlt: { backgroundColor: "#0f172a50" },
  colData: { color: "#f1f5f9", fontSize: 11, fontFamily: "monospace" },
  empty: { padding: 24, alignItems: "center", gap: 4 },
  emptyText: { color: "#64748b", fontSize: 13, fontWeight: "600" },
  emptySubText: { color: "#475569", fontSize: 11 },
  statusCard: { backgroundColor: "#1e293b", borderRadius: 12, padding: 14, borderWidth: 1, borderColor: "#334155", alignItems: "center", gap: 4 },
  statusLabel: { color: "#64748b", fontSize: 10, fontWeight: "700", textTransform: "uppercase", letterSpacing: 1 },
  statusValue: { color: "#10b981", fontSize: 22, fontWeight: "800", fontFamily: "monospace" },
  statusBadge: { fontSize: 10, fontWeight: "700", paddingHorizontal: 10, paddingVertical: 3, borderRadius: 20 },
  badgeComplete: { backgroundColor: "#052e16", color: "#10b981", borderWidth: 1, borderColor: "#166534" },
  badgeIncomplete: { backgroundColor: "#451a03", color: "#f59e0b", borderWidth: 1, borderColor: "#92400e" },
  actionRow: { flexDirection: "row", gap: 10 },
  btn: { flex: 1, paddingVertical: 14, borderRadius: 12, alignItems: "center" },
  btnPrimary: { backgroundColor: "#1d4ed8" },
  btnDanger: { backgroundColor: "#7f1d1d" },
  btnDisabled: { opacity: 0.4 },
  btnText: { color: "#fff", fontSize: 13, fontWeight: "700" },
  infoCard: { backgroundColor: "#1e293b", borderRadius: 12, padding: 14, borderWidth: 1, borderColor: "#334155", gap: 6 },
  infoTitle: { color: "#94a3b8", fontSize: 10, fontWeight: "700", textTransform: "uppercase", letterSpacing: 1 },
  infoText: { color: "#64748b", fontSize: 11, lineHeight: 18 },
});
