import { Feather } from "@expo/vector-icons";
import { CameraView, useCameraPermissions } from "expo-camera";
import React, { useCallback, useEffect, useState } from "react";
import {
  Dimensions,
  Modal,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { Line, Rect, Svg, Text as SvgText } from "react-native-svg";

import { useApp } from "@/context/AppContext";
import { useCameraSync } from "@/hooks/useCameraSync";

const SCREEN_W = Dimensions.get("window").width;
const SCREEN_H = Dimensions.get("window").height;
const GAUGE_H = 80;

// ── Interval histogram ────────────────────────────────────────────────────────
const HIST_H = 72;
const HIST_PTOP = 4;
const HIST_PBOT = 14;
const HIST_CHART_H = HIST_H - HIST_PTOP - HIST_PBOT;
const HIST_MAX_BARS = 32;

function barColor(dev: number): string {
  if (dev <= 0.1) return "#22c55e";
  if (dev <= 0.25) return "#f59e0b";
  return "#ef4444";
}

function IntervalHistogram({
  intervals,
  width,
}: {
  intervals: number[];
  width: number;
}) {
  if (intervals.length < 2) {
    return (
      <View style={histStyles.empty}>
        <Text style={histStyles.emptyText}>
          In attesa di impulsi per l'istogramma...
        </Text>
      </View>
    );
  }

  const minV = Math.min(...intervals);
  const maxV = Math.max(...intervals);
  const range = maxV - minV || 1;
  const mean = intervals.reduce((a, b) => a + b, 0) / intervals.length;

  const variance =
    intervals.reduce((a, b) => a + (b - mean) ** 2, 0) / intervals.length;
  const cv = Math.sqrt(variance) / (mean || 1);
  const stability = Math.round(Math.max(0, Math.min(100, (1 - cv) * 100)));
  const stabColor =
    stability >= 90 ? "#22c55e" : stability >= 70 ? "#f59e0b" : "#ef4444";

  const gap = 1;
  const barW = Math.max(3, Math.floor((width - gap * (intervals.length - 1)) / intervals.length));
  const totalW = intervals.length * (barW + gap) - gap;

  const scaleH = (v: number) =>
    Math.max(3, ((v - minV) / range) * HIST_CHART_H);

  const meanBarH = scaleH(mean);
  const meanY = HIST_PTOP + HIST_CHART_H - meanBarH;

  return (
    <View style={{ gap: 4 }}>
      {/* Header row */}
      <View style={histStyles.headerRow}>
        <Text style={histStyles.label}>INTERVALLI INTER-IMPULSO (ms)</Text>
        <View style={[histStyles.stabilityBadge, { borderColor: stabColor }]}>
          <Text style={[histStyles.stabilityText, { color: stabColor }]}>
            STABILITÀ {stability}%
          </Text>
        </View>
      </View>

      {/* SVG chart */}
      <Svg width={totalW} height={HIST_H}>
        {intervals.map((v, i) => {
          const bH = scaleH(v);
          const bX = i * (barW + gap);
          const bY = HIST_PTOP + HIST_CHART_H - bH;
          const dev = Math.abs(v - mean) / (mean || 1);
          return (
            <Rect
              key={i}
              x={bX}
              y={bY}
              width={barW}
              height={bH}
              rx={1}
              fill={barColor(dev)}
              opacity={0.85}
            />
          );
        })}

        {/* Mean dashed line */}
        <Line
          x1={0}
          y1={meanY}
          x2={totalW}
          y2={meanY}
          stroke="rgba(255,255,255,0.45)"
          strokeWidth={1}
          strokeDasharray="4,3"
        />

        {/* Mean label */}
        <SvgText
          x={totalW - 2}
          y={meanY - 3}
          fontSize={8}
          fill="rgba(255,255,255,0.55)"
          textAnchor="end"
        >
          μ {Math.round(mean)}ms
        </SvgText>

        {/* Axis: min / max labels */}
        <SvgText
          x={0}
          y={HIST_H - 2}
          fontSize={8}
          fill="rgba(148,163,184,0.7)"
        >
          min {Math.round(minV)}ms
        </SvgText>
        <SvgText
          x={totalW}
          y={HIST_H - 2}
          fontSize={8}
          fill="rgba(148,163,184,0.7)"
          textAnchor="end"
        >
          max {Math.round(maxV)}ms
        </SvgText>
      </Svg>

      {/* Legend */}
      <View style={histStyles.legend}>
        <View style={histStyles.legendItem}>
          <View style={[histStyles.legendDot, { backgroundColor: "#22c55e" }]} />
          <Text style={histStyles.legendText}>≤10% dev.</Text>
        </View>
        <View style={histStyles.legendItem}>
          <View style={[histStyles.legendDot, { backgroundColor: "#f59e0b" }]} />
          <Text style={histStyles.legendText}>10–25%</Text>
        </View>
        <View style={histStyles.legendItem}>
          <View style={[histStyles.legendDot, { backgroundColor: "#ef4444" }]} />
          <Text style={histStyles.legendText}>{">"}25% (anomalia)</Text>
        </View>
      </View>
    </View>
  );
}

const histStyles = StyleSheet.create({
  empty: {
    height: HIST_H,
    alignItems: "center",
    justifyContent: "center",
  },
  emptyText: { color: "#475569", fontSize: 10, fontStyle: "italic" },
  headerRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  label: { color: "#475569", fontSize: 8, fontWeight: "800", letterSpacing: 0.5 },
  stabilityBadge: {
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  stabilityText: { fontSize: 9, fontWeight: "800" },
  legend: { flexDirection: "row", gap: 10, justifyContent: "center" },
  legendItem: { flexDirection: "row", alignItems: "center", gap: 4 },
  legendDot: { width: 7, height: 7, borderRadius: 2 },
  legendText: { color: "#475569", fontSize: 8 },
});

export function CameraSyncOverlay() {
  const [permission, requestPermission] = useCameraPermissions();
  const [liveModalOpen, setLiveModalOpen] = useState(false);
  const { isRecording, receiveCameraPulse } = useApp();

  const handlePulse = useCallback(
    (ts: number, idx: number) => receiveCameraPulse(ts, idx),
    [receiveCameraPulse]
  );

  const {
    cameraRef,
    brightness,
    pulseCount,
    estimatedRPM,
    intervalHistory,
    isActive,
    calibState,
    isCalibrated,
    start,
    stop,
    calibrateDark,
    calibrateBright,
    resetCalib,
  } = useCameraSync({ onPulse: handlePulse });

  // Auto start/stop the capture loop based on recording state
  useEffect(() => {
    if (isRecording && isCalibrated && !isActive) start();
    else if (!isRecording && isActive) stop();
  }, [isRecording, isCalibrated, isActive, start, stop]);

  // Apri automaticamente la vista live quando inizia l'acquisizione
  useEffect(() => {
    if (isActive) setLiveModalOpen(true);
  }, [isActive]);

  // Web: not supported
  if (Platform.OS === "web") return null;

  const briColor =
    brightness < 85 ? "#ef4444" : brightness < 170 ? "#f59e0b" : "#22c55e";
  const fillH = Math.round((brightness / 255) * GAUGE_H);

  // ── Permission request ────────────────────────────────────────────────────
  if (!permission?.granted) {
    return (
      <View style={styles.card}>
        <Text style={styles.title}>📷  Camera Sync — Encoder Ottico</Text>
        <Text style={styles.desc}>
          Autorizza la fotocamera per rilevare le finestre bianche del rotore e
          sincronizzare la velocità di rotazione.
        </Text>
        <Pressable onPress={requestPermission} style={styles.btnPrimary}>
          <Text style={styles.btnPrimaryText}>Autorizza fotocamera</Text>
        </Pressable>
      </View>
    );
  }

  // ── Compact card (always visible in CAM mode) ─────────────────────────────
  return (
    <>
      <View style={styles.card}>
        {/* Header */}
        <View style={styles.headerRow}>
          <Text style={styles.title}>📷  Camera Sync — Encoder Ottico</Text>
          <View style={styles.headerActions}>
            {isCalibrated && (
              <Pressable onPress={resetCalib} style={styles.resetBtn}>
                <Text style={styles.resetBtnText}>Reset</Text>
              </Pressable>
            )}
            <Pressable
              onPress={() => setLiveModalOpen(true)}
              style={styles.btnLive}
            >
              <View style={styles.liveDot} />
              <Text style={styles.btnLiveText}>Vista live</Text>
            </Pressable>
          </View>
        </View>

        {/* Compact status row */}
        <View style={styles.statusRow}>
          {/* Mini brightness bar (horizontal) */}
          <View style={styles.hGaugeWrap}>
            <Text style={styles.statLabel}>LUM</Text>
            <View style={styles.hGaugeTrack}>
              <View
                style={[
                  styles.hGaugeFill,
                  {
                    width: `${Math.round((brightness / 255) * 100)}%`,
                    backgroundColor: briColor,
                  },
                ]}
              />
            </View>
          </View>

          {/* Pulse count */}
          <View style={styles.statBox}>
            <Text style={styles.statLabel}>IMPULSI</Text>
            <Text style={styles.statValue}>{pulseCount}</Text>
          </View>

          {/* RPM ottico */}
          <View style={styles.statBox}>
            <Text style={styles.statLabel}>RPM OTT.</Text>
            <Text style={[styles.statValue, { color: "#22c55e" }]}>
              {estimatedRPM !== null ? estimatedRPM.toFixed(2) : "--.-"}
            </Text>
          </View>

          {/* Live indicator */}
          <View style={[styles.liveDotBig, { backgroundColor: isActive ? "#22c55e" : "#334155" }]} />
        </View>

        {/* Calibration status */}
        {!isCalibrated ? (
          <Text style={styles.calibHintCompact}>
            {calibState === "none"
              ? "⚠  Apri Vista Live per calibrare SCURO → BIANCO prima di avviare"
              : "⚠  Passo 2: apri Vista Live, punta sulla finestra bianca e premi BIANCO"}
          </Text>
        ) : (
          <View style={styles.readyBadge}>
            <Text style={styles.readyText}>
              ✓  Calibrazione OK — premi AVVIA per iniziare
            </Text>
          </View>
        )}
      </View>

      {/* ── Full-screen live camera modal ─────────────────────────────────── */}
      <Modal
        visible={liveModalOpen}
        animationType="slide"
        statusBarTranslucent
        onRequestClose={() => setLiveModalOpen(false)}
      >
        <View style={styles.modalRoot}>
          {/* Full-screen camera */}
          <CameraView
            ref={cameraRef as React.RefObject<CameraView>}
            style={StyleSheet.absoluteFillObject}
            facing="back"
          />

          {/* Dark gradient at top for controls */}
          <View style={styles.modalTop}>
            <View style={styles.modalTitleRow}>
              <Text style={styles.modalTitle}>📷  Camera Sync — Vista Live</Text>
              <Pressable
                onPress={() => setLiveModalOpen(false)}
                style={styles.btnClose}
              >
                <Feather name="x" size={22} color="#fff" />
              </Pressable>
            </View>

            {/* Top stats bar */}
            <View style={styles.modalStats}>
              <View style={styles.modalStatChip}>
                <Text style={styles.modalStatLabel}>IMPULSI</Text>
                <Text style={styles.modalStatValue}>{pulseCount}</Text>
              </View>
              <View style={styles.modalStatChip}>
                <Text style={styles.modalStatLabel}>RPM OTTICO</Text>
                <Text style={[styles.modalStatValue, { color: "#22c55e" }]}>
                  {estimatedRPM !== null ? estimatedRPM.toFixed(2) : "--.-"}
                </Text>
              </View>
              <View style={styles.modalStatChip}>
                <Text style={styles.modalStatLabel}>STATO</Text>
                <View style={[styles.pulseDot, { backgroundColor: isActive ? "#22c55e" : "#475569" }]} />
              </View>
            </View>
          </View>

          {/* Center ROI crosshair */}
          <View style={styles.roiContainer} pointerEvents="none">
            <View style={styles.roiHoriz} />
            <View style={styles.roiVert} />
            <View style={styles.roiRect} />
            <Text style={styles.roiLabel}>ROI — punta qui sulle finestre</Text>
          </View>

          {/* Right-side vertical brightness gauge */}
          <View style={styles.vGaugeContainer} pointerEvents="none">
            <Text style={styles.vGaugeLabel}>LUM</Text>
            <View style={styles.vGaugeTrack}>
              <View
                style={[
                  styles.vGaugeFill,
                  { height: fillH, backgroundColor: briColor },
                ]}
              />
            </View>
            <Text style={[styles.vGaugeValue, { color: briColor }]}>
              {brightness}
            </Text>
          </View>

          {/* Bottom calibration controls + histogram */}
          <View style={styles.modalBottom}>
            {/* Interval histogram (shown once acquisition starts) */}
            <IntervalHistogram
              intervals={intervalHistory}
              width={SCREEN_W - 40}
            />

            <View style={styles.histDivider} />

            {!isCalibrated ? (
              <>
                <Text style={styles.calibInstruction}>
                  {calibState === "none"
                    ? "Passo 1 di 2 — punta sulla lamiera scura e premi SCURO"
                    : "Passo 2 di 2 — punta sulla finestra bianca e premi BIANCO"}
                </Text>
                <View style={styles.calibBtnRow}>
                  <Pressable onPress={calibrateDark} style={styles.btnDark}>
                    <Text style={styles.btnDarkText}>⬛  SCURO</Text>
                  </Pressable>
                  <View
                    style={[
                      styles.calibDivider,
                      {
                        backgroundColor:
                          calibState === "dark_done" ? "#22c55e" : "#334155",
                      },
                    ]}
                  />
                  <Pressable
                    onPress={calibrateBright}
                    disabled={calibState === "none"}
                    style={[
                      styles.btnBright,
                      calibState === "none" && styles.btnDisabled,
                    ]}
                  >
                    <Text style={styles.btnBrightText}>⬜  BIANCO</Text>
                  </Pressable>
                </View>
              </>
            ) : (
              <View style={styles.modalReadyRow}>
                <View style={styles.modalReadyBadge}>
                  <Text style={styles.modalReadyText}>
                    ✓  Calibrazione completata
                  </Text>
                </View>
                <Pressable onPress={resetCalib} style={styles.btnResetModal}>
                  <Text style={styles.btnResetModalText}>Reset</Text>
                </Pressable>
                <Pressable
                  onPress={() => setLiveModalOpen(false)}
                  style={styles.btnStartHint}
                >
                  <Feather name="arrow-down-circle" size={14} color="#60a5fa" />
                  <Text style={styles.btnStartHintText}>
                    Chiudi e premi AVVIA
                  </Text>
                </Pressable>
              </View>
            )}
          </View>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  // ── Compact card ───────────────────────────────────────────────────────────
  card: {
    backgroundColor: "#070f1c",
    borderTopWidth: 1,
    borderTopColor: "#1e3a5f",
    paddingHorizontal: 12,
    paddingTop: 10,
    paddingBottom: 12,
    gap: 8,
  },
  headerRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  title: { color: "#60a5fa", fontSize: 11, fontWeight: "800", letterSpacing: 0.8 },
  desc: { color: "#64748b", fontSize: 11, lineHeight: 16 },
  headerActions: { flexDirection: "row", alignItems: "center", gap: 6 },
  resetBtn: {
    backgroundColor: "#1e293b",
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  resetBtnText: { color: "#ef4444", fontSize: 10, fontWeight: "700" },
  btnLive: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    backgroundColor: "#1e3a8a",
    borderRadius: 7,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderWidth: 1,
    borderColor: "#3b82f6",
  },
  liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: "#f87171" },
  btnLiveText: { color: "#93c5fd", fontSize: 11, fontWeight: "800" },

  // Status row
  statusRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  hGaugeWrap: { flex: 1, gap: 2 },
  hGaugeTrack: {
    height: 6,
    backgroundColor: "#1e293b",
    borderRadius: 3,
    overflow: "hidden",
  },
  hGaugeFill: { height: "100%", borderRadius: 3 },
  statBox: {
    alignItems: "center",
    backgroundColor: "#0f172a",
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 5,
    gap: 1,
    minWidth: 58,
  },
  statLabel: { color: "#475569", fontSize: 7, fontWeight: "800", letterSpacing: 0.5 },
  statValue: { color: "#f8fafc", fontSize: 14, fontWeight: "800", fontFamily: "monospace" },
  liveDotBig: { width: 12, height: 12, borderRadius: 6, alignSelf: "center" },

  calibHintCompact: {
    color: "#64748b",
    fontSize: 10,
    fontStyle: "italic",
  },
  readyBadge: {
    backgroundColor: "#052e16",
    borderWidth: 1,
    borderColor: "#166534",
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 6,
    alignItems: "center",
  },
  readyText: { color: "#4ade80", fontSize: 11, fontWeight: "700" },

  btnPrimary: {
    backgroundColor: "#1d4ed8",
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 16,
    alignItems: "center",
  },
  btnPrimaryText: { color: "#fff", fontWeight: "800", fontSize: 13 },

  // ── Full-screen modal ──────────────────────────────────────────────────────
  modalRoot: {
    flex: 1,
    backgroundColor: "#000",
  },

  // Top controls overlay
  modalTop: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    backgroundColor: "rgba(0,0,0,0.65)",
    paddingTop: 48,
    paddingHorizontal: 16,
    paddingBottom: 12,
    gap: 10,
  },
  modalTitleRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  modalTitle: {
    color: "#60a5fa",
    fontSize: 13,
    fontWeight: "800",
    letterSpacing: 0.5,
  },
  btnClose: {
    backgroundColor: "rgba(15,23,42,0.7)",
    borderRadius: 20,
    padding: 6,
  },
  modalStats: { flexDirection: "row", gap: 8 },
  modalStatChip: {
    flex: 1,
    backgroundColor: "rgba(15,23,42,0.8)",
    borderRadius: 10,
    paddingVertical: 7,
    paddingHorizontal: 10,
    alignItems: "center",
    gap: 2,
  },
  modalStatLabel: { color: "#475569", fontSize: 8, fontWeight: "800", letterSpacing: 0.5 },
  modalStatValue: { color: "#f8fafc", fontSize: 18, fontWeight: "800", fontFamily: "monospace" },
  pulseDot: { width: 16, height: 16, borderRadius: 8 },

  // ROI crosshair (centered)
  roiContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: "center",
    justifyContent: "center",
  },
  roiHoriz: {
    position: "absolute",
    left: 0,
    right: 0,
    height: 1,
    backgroundColor: "rgba(251,191,36,0.5)",
  },
  roiVert: {
    position: "absolute",
    top: 0,
    bottom: 0,
    width: 1,
    backgroundColor: "rgba(251,191,36,0.5)",
  },
  roiRect: {
    width: 80,
    height: 80,
    borderWidth: 2,
    borderColor: "#f59e0b",
    borderRadius: 6,
    backgroundColor: "transparent",
  },
  roiLabel: {
    position: "absolute",
    top: "50%",
    color: "#fbbf24",
    fontSize: 10,
    fontWeight: "700",
    backgroundColor: "rgba(0,0,0,0.5)",
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 4,
    marginTop: 52,
  },

  // Vertical brightness gauge (right side)
  vGaugeContainer: {
    position: "absolute",
    right: 16,
    top: "35%",
    alignItems: "center",
    gap: 4,
  },
  vGaugeLabel: {
    color: "rgba(255,255,255,0.6)",
    fontSize: 9,
    fontWeight: "800",
    letterSpacing: 1,
  },
  vGaugeTrack: {
    width: 20,
    height: GAUGE_H,
    backgroundColor: "rgba(30,41,59,0.8)",
    borderRadius: 8,
    overflow: "hidden",
    justifyContent: "flex-end",
  },
  vGaugeFill: { width: "100%", borderRadius: 8, minHeight: 3 },
  vGaugeValue: {
    fontSize: 13,
    fontWeight: "800",
    fontFamily: "monospace",
  },

  histDivider: {
    height: 1,
    backgroundColor: "rgba(255,255,255,0.08)",
    marginHorizontal: -20,
  },

  // Bottom calibration overlay
  modalBottom: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: "rgba(0,0,0,0.72)",
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 36,
    gap: 14,
  },
  calibInstruction: {
    color: "#94a3b8",
    fontSize: 12,
    textAlign: "center",
    fontStyle: "italic",
  },
  calibBtnRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  btnDark: {
    flex: 1,
    backgroundColor: "#1e293b",
    borderWidth: 1,
    borderColor: "#64748b",
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: "center",
  },
  btnDarkText: { color: "#cbd5e1", fontSize: 15, fontWeight: "800" },
  calibDivider: { width: 2, height: 52, borderRadius: 1 },
  btnBright: {
    flex: 1,
    backgroundColor: "#172554",
    borderWidth: 1,
    borderColor: "#3b82f6",
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: "center",
  },
  btnBrightText: { color: "#93c5fd", fontSize: 15, fontWeight: "800" },
  btnDisabled: { opacity: 0.35 },

  // Modal ready state
  modalReadyRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    flexWrap: "wrap",
  },
  modalReadyBadge: {
    flex: 1,
    backgroundColor: "#052e16",
    borderWidth: 1,
    borderColor: "#166534",
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 12,
    alignItems: "center",
  },
  modalReadyText: { color: "#4ade80", fontSize: 13, fontWeight: "700" },
  btnResetModal: {
    backgroundColor: "#1e293b",
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  btnResetModalText: { color: "#ef4444", fontSize: 12, fontWeight: "700" },
  btnStartHint: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: "#172554",
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: "#3b82f6",
  },
  btnStartHintText: { color: "#60a5fa", fontSize: 11, fontWeight: "700" },
});
