import React, { useMemo } from "react";
import { Text, View, useWindowDimensions } from "react-native";
import Svg, { G, Line, Path, Text as SvgText } from "react-native-svg";

import { useApp } from "@/context/AppContext";

export function LinearChart() {
  const {
    data, currentAngle, targetRotations, MAX_FLUX, isRecording, failFactor,
    showAxisX, showAxisY, showAxisZ, showResultant,
  } = useApp();
  const { width: screenWidth } = useWindowDimensions();
  const width = screenWidth - 32;
  const height = 220;
  const centerY = height / 2;
  const safeRotations = Math.max(1, targetRotations);
  const maxAngle = safeRotations * 360;

  const paths = useMemo(() => {
    if (data.length === 0) return { x: "", y: "", z: "", r: "" };

    const buildPath = (getValue: (d: (typeof data)[0]) => number) => {
      const pts = data.map((d) => {
        const px = (Math.max(0, d.angle) / maxAngle) * width;
        const py = centerY - (getValue(d) / MAX_FLUX) * (height / 2.5);
        return `${px.toFixed(1)},${py.toFixed(1)}`;
      });
      return pts.length > 1 ? `M ${pts.join(" L ")}` : "";
    };

    return {
      x: buildPath((d) => d.x || 0),
      y: buildPath((d) => d.y || 0),
      z: buildPath((d) => d.z || 0),
      r: buildPath((d) => Math.sqrt((d.x || 0) ** 2 + (d.y || 0) ** 2 + (d.z || 0) ** 2)),
    };
  }, [data, width, height, centerY, maxAngle, MAX_FLUX]);

  const currentX = (currentAngle / maxAngle) * width;

  const gridLines = [];
  for (let i = 0; i <= safeRotations; i++) {
    const gx = (i * 360 / maxAngle) * width;
    gridLines.push(
      <G key={`grid-${i}`}>
        <Line x1={gx} y1={0} x2={gx} y2={height} stroke="#1e293b" strokeWidth={1} strokeDasharray="4,4" />
        <SvgText x={gx + 4} y={height - 6} fill="#475569" fontSize={9} fontFamily="monospace">Giro {i}</SvgText>
      </G>
    );
  }

  return (
    <View style={{ borderRadius: 12, overflow: "hidden", backgroundColor: "#0f172a" }}>
      {isRecording && failFactor < 0.99 && (
        <View style={{
          position: "absolute", top: 8, right: 8, backgroundColor: "rgba(69,10,10,0.9)",
          borderColor: "#ef4444", borderWidth: 1, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 4, zIndex: 10
        }}>
          <Text style={{ color: "#fca5a5", fontSize: 10, fontFamily: "monospace", fontWeight: "bold" }}>
            TURBATIVA: {(failFactor * 100).toFixed(0)}%
          </Text>
        </View>
      )}
      <Svg width={width} height={height}>
        <Line x1={0} y1={centerY} x2={width} y2={centerY} stroke="#475569" strokeWidth={1} strokeDasharray="4,4" />
        {gridLines}
        {showAxisX && paths.x ? <Path d={paths.x} fill="none" stroke="#ef4444" strokeWidth={2} strokeLinejoin="round" /> : null}
        {showAxisY && paths.y ? <Path d={paths.y} fill="none" stroke="#10b981" strokeWidth={2} strokeLinejoin="round" /> : null}
        {showAxisZ && paths.z ? <Path d={paths.z} fill="none" stroke="#3b82f6" strokeWidth={2} strokeLinejoin="round" /> : null}
        {showResultant && paths.r ? <Path d={paths.r} fill="none" stroke="#f59e0b" strokeWidth={2.5} strokeLinejoin="round" strokeDasharray="6,3" /> : null}
        <Line x1={currentX} y1={0} x2={currentX} y2={height} stroke="#f59e0b" strokeWidth={2} />
      </Svg>
    </View>
  );
}
