import React, { useMemo } from "react";
import { View, useWindowDimensions } from "react-native";
import Svg, { Circle, Ellipse, G, Path, Rect, Text as SvgText } from "react-native-svg";

import { useApp } from "@/context/AppContext";

function polarToPath(
  cx: number, cy: number, r: number,
  startAngleDeg: number, endAngleDeg: number,
  innerR: number
): string {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const s = toRad(startAngleDeg);
  const e = toRad(endAngleDeg);
  const x1 = cx + r * Math.cos(s);
  const y1 = cy + r * Math.sin(s);
  const x2 = cx + r * Math.cos(e);
  const y2 = cy + r * Math.sin(e);
  const ix1 = cx + innerR * Math.cos(e);
  const iy1 = cy + innerR * Math.sin(e);
  const ix2 = cx + innerR * Math.cos(s);
  const iy2 = cy + innerR * Math.sin(s);
  const large = endAngleDeg - startAngleDeg > 180 ? 1 : 0;
  return `M${x1},${y1} A${r},${r} 0 ${large},1 ${x2},${y2} L${ix1},${iy1} A${innerR},${innerR} 0 ${large},0 ${ix2},${iy2} Z`;
}

function fluxColor(flux: number, maxFlux: number): string {
  const ratio = Math.max(-1, Math.min(1, flux / maxFlux));
  if (ratio < 0) {
    const i = Math.floor(Math.abs(ratio) * 200);
    return `rgb(30,41,${59 + i})`;
  } else {
    const i = Math.floor(ratio * 200);
    return `rgb(${80 + i},30,30)`;
  }
}

export function Fem2D() {
  const {
    sessions, failFactor, zOffset, selected2DStep, setSelected2DStep,
    isRecording, currentAngle, activeSteps, MAX_FLUX,
    show2DFluxLines, femGain,
  } = useApp();

  const { width: screenWidth } = useWindowDimensions();
  const size = Math.min(screenWidth - 32, 300);
  const cx = size / 2;
  const cy = size / 2;
  const outerR = size * 0.43;
  const innerR = size * 0.13;
  const poleR = size * 0.36;

  const isCurrentSlice = isRecording && Math.abs(zOffset - selected2DStep) < 0.1;
  const activeSession = sessions.find((s) => Math.abs(s.z - selected2DStep) < 0.1);
  const isMeasured = isCurrentSlice || !!activeSession;

  const rotationOffset = isCurrentSlice ? (currentAngle * Math.PI) / 180 : 0;

  const sectors = useMemo(() => {
    const result: { path: string; color: string }[] = [];
    const BUCKET = 4;
    for (let angleDeg = 0; angleDeg < 360; angleDeg += BUCKET) {
      const relAngle = (angleDeg - (rotationOffset * 180) / Math.PI + 720) % 360;
      let flux = 0;
      if (isCurrentSlice) {
        flux = Math.sin(4 * (relAngle * Math.PI) / 180) * 1600 * failFactor;
      } else if (activeSession) {
        const idx = Math.floor(relAngle) % 360;
        const pt = activeSession.data.find((d) => d.angle === idx);
        flux = pt ? pt.x : 0;
      } else {
        flux = Math.sin(4 * (relAngle * Math.PI) / 180) * 1600;
      }
      const ratio = Math.max(-1, Math.min(1, flux / femGain));
      let color: string;
      if (!isMeasured) {
        const intensity = Math.abs(ratio);
        color = `rgba(57,${Math.floor(100 + 155 * intensity)},20,${0.5 + 0.5 * intensity})`;
      } else {
        color = fluxColor(flux, femGain);
      }
      const path = polarToPath(cx, cy, outerR, angleDeg, angleDeg + BUCKET, poleR * 0.7);
      result.push({ path, color });
    }
    return result;
  }, [isCurrentSlice, activeSession, failFactor, rotationOffset, femGain, isMeasured, cx, cy, outerR, poleR]);

  const statorPath = polarToPath(cx, cy, outerR, 0, 360, outerR - 6);

  return (
    <View style={{ alignItems: "center" }}>
      <Svg width={size} height={size}>
        {sectors.map((s, i) => (
          <Path key={i} d={s.path} fill={s.color} />
        ))}
        <Circle cx={cx} cy={cy} r={outerR} stroke="#475569" strokeWidth={2} fill="none" />
        <G rotation={`${(rotationOffset * 180) / Math.PI}`} origin={`${cx},${cy}`}>
          {Array.from({ length: 8 }, (_, i) => {
            const ang = (i * 45 * Math.PI) / 180;
            const poleAngle = ang + (22.5 * Math.PI) / 180;
            const px = cx + poleR * Math.cos(poleAngle);
            const py = cy + poleR * Math.sin(poleAngle);
            const mFlux = isCurrentSlice
              ? Math.abs(Math.sin(4 * ((i * 45 + 12.5) * Math.PI) / 180)) * failFactor
              : activeSession
              ? Math.abs(activeSession.data.find((d) => d.angle === Math.floor(i * 45 + 12.5) % 360)?.x ?? 0) / MAX_FLUX
              : 0.5;
            const arcR = Math.max(8, 14 * mFlux);
            return (
              <Ellipse key={i} cx={px} cy={py} rx={arcR} ry={arcR * 0.6}
                stroke={show2DFluxLines ? (isMeasured ? "rgba(255,255,255,0.25)" : "rgba(57,255,20,0.25)") : "none"}
                strokeWidth={1} fill="none" />
            );
          })}
          <Circle cx={cx} cy={cy} r={innerR} fill="#0f172a" stroke="#475569" strokeWidth={2} />
          {Array.from({ length: 24 }, (_, i) => {
            const ang = (i * 15 * Math.PI) / 180;
            const r1 = innerR, r2 = innerR + 6;
            return (
              <Path key={i}
                d={`M${cx + r1 * Math.cos(ang)},${cy + r1 * Math.sin(ang)} L${cx + r2 * Math.cos(ang)},${cy + r2 * Math.sin(ang)}`}
                stroke="#475569" strokeWidth={1.5}
              />
            );
          })}
        </G>
        <SvgText x={cx} y={size - 8} fill="#64748b" fontSize={9} textAnchor="middle" fontFamily="monospace">
          Quota: {selected2DStep} mm | {isMeasured ? (isCurrentSlice ? "IN ACQUISIZIONE" : "ACQUISITO") : "NON CAMPIONATO"}
        </SvgText>
      </Svg>
    </View>
  );
}
