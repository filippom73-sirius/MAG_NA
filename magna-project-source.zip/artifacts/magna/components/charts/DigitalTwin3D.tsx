import React, { useMemo, useRef } from "react";
import { PanResponder, StyleSheet, View, useWindowDimensions } from "react-native";
import Svg, { Line as SvgLine, Polygon } from "react-native-svg";

import { useApp } from "@/context/AppContext";

type Point2D = { x: number; y: number; depth: number };
type Poly = { type: "poly"; pts: Point2D[]; color: string; depth: number };
type LineEl = { type: "line"; p1: Point2D; p2: Point2D; color: string; width: number; depth: number };

function fluxColor(fluxValue: number, MAX_FLUX: number): string {
  const ratio = Math.max(-1, Math.min(1, fluxValue / MAX_FLUX));
  if (ratio < 0) {
    const intensity = Math.floor(Math.abs(ratio) * 200);
    return `rgb(30,41,${59 + intensity})`;
  } else {
    const intensity = Math.floor(ratio * 200);
    return `rgb(${50 + intensity},30,30)`;
  }
}

export function DigitalTwin3D() {
  const {
    rotX, setRotX, rotY, setRotY, zoomScale, setZoomScale,
    sessions, failFactor, paccoHeight, activeSteps,
    zOffset, isRecording, showFluxLines, MAX_FLUX,
    hiddenZSlices,
  } = useApp();

  const { width: screenWidth } = useWindowDimensions();
  const W = screenWidth - 32;
  const H = 280;

  const isDragging = useRef(false);
  const dragStart = useRef({ x: 0, y: 0, rotX: -0.5, rotY: 0.8 });

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: (e) => {
        isDragging.current = true;
        dragStart.current = {
          x: e.nativeEvent.pageX,
          y: e.nativeEvent.pageY,
          rotX: rotX,
          rotY: rotY,
        };
      },
      onPanResponderMove: (e) => {
        if (!isDragging.current) return;
        const dx = e.nativeEvent.pageX - dragStart.current.x;
        const dy = e.nativeEvent.pageY - dragStart.current.y;
        setRotY(dragStart.current.rotY + dx * 0.01);
        setRotX(dragStart.current.rotX + dy * 0.01);
      },
      onPanResponderRelease: () => { isDragging.current = false; },
    })
  ).current;

  const elements = useMemo(() => {
    const project = (x: number, y: number, z: number): Point2D => {
      const cosY = Math.cos(rotY), sinY = Math.sin(rotY);
      const x1 = x * cosY - z * sinY;
      const z1 = x * sinY + z * cosY;
      const cosX = Math.cos(rotX), sinX = Math.sin(rotX);
      const y2 = y * cosX - z1 * sinX;
      const z2 = y * sinX + z1 * cosX;
      const camDist = 320;
      const scale = 140 * zoomScale;
      const depth = z2 + camDist;
      return {
        x: (x1 * scale) / depth + W / 2,
        y: (y2 * scale) / depth + H / 2,
        depth: z2,
      };
    };

    const polys: (Poly | LineEl)[] = [];
    const SEGS = 16;
    const baseLengthFactor = 120;
    const rotorLength = (paccoHeight / 50) * baseLengthFactor;
    const rotorRadius = 32;

    const addCylinder = (
      radius: number, zStart: number, zEnd: number, baseColor: string,
      isRotorBody = false, sliceIndex = -1
    ) => {
      const isHidden = isRotorBody && sliceIndex !== -1 && hiddenZSlices.includes(activeSteps[sliceIndex]);

      for (let i = 0; i < SEGS; i++) {
        const t1 = (i * 2 * Math.PI) / SEGS;
        const t2 = ((i + 1) * 2 * Math.PI) / SEGS;
        const v1 = project(radius * Math.cos(t1), radius * Math.sin(t1), zStart);
        const v2 = project(radius * Math.cos(t2), radius * Math.sin(t2), zStart);
        const v3 = project(radius * Math.cos(t2), radius * Math.sin(t2), zEnd);
        const v4 = project(radius * Math.cos(t1), radius * Math.sin(t1), zEnd);
        const avgDepth = (v1.depth + v2.depth + v3.depth + v4.depth) / 4;

        let polyColor = baseColor;

        if (isHidden) {
          polyColor = "rgba(30,41,59,0.18)";
        } else if (isRotorBody && sliceIndex !== -1) {
          const angleDeg = (i * 360) / SEGS;
          const relAngle = angleDeg % 45;
          if (relAngle >= 25 && relAngle < 45) {
            polyColor = "#f1f5f9";
          } else {
            const stepZVal = activeSteps[sliceIndex];
            const isCurrentSlice = isRecording && Math.abs(zOffset - stepZVal) < 0.1;
            const matchSession = sessions.find((s) => Math.abs(s.z - stepZVal) < 0.1);
            if (isCurrentSlice) {
              const baseFlux = Math.sin(4 * (angleDeg * Math.PI) / 180) * 1600;
              polyColor = fluxColor(baseFlux * failFactor, MAX_FLUX);
            } else if (matchSession) {
              const pt = matchSession.data.find((d) => d.angle === Math.floor(angleDeg) % 360);
              polyColor = fluxColor(pt ? pt.x : 0, MAX_FLUX);
            } else {
              polyColor = "#39ff14";
            }
          }
        }

        polys.push({ type: "poly", pts: [v1, v2, v3, v4], color: polyColor, depth: avgDepth });
      }
    };

    const addFluxLines = () => {
      if (!showFluxLines) return;
      const N = activeSteps.length;
      const sliceWidth = rotorLength / N;
      const poleAngles = Array.from({ length: 8 }, (_, i) => i * 45 + 12.5);

      for (let s = 0; s < N; s++) {
        if (hiddenZSlices.includes(activeSteps[s])) continue;
        const stepZVal = activeSteps[s];
        const zMid = -rotorLength / 2 + s * sliceWidth + sliceWidth / 2;
        const isCurrentSlice = isRecording && Math.abs(zOffset - stepZVal) < 0.1;
        const matchSession = sessions.find((sess) => Math.abs(sess.z - stepZVal) < 0.1);
        const isMeasured = isCurrentSlice || !!matchSession;

        const poleFluxes = poleAngles.map((angleDeg) => {
          if (isCurrentSlice) return Math.sin(4 * (angleDeg * Math.PI) / 180) * 1600 * failFactor;
          if (matchSession) {
            const pt = matchSession.data.find((d) => d.angle === Math.floor(angleDeg) % 360);
            return pt ? pt.x : 0;
          }
          return 0;
        });

        for (let pi = 0; pi < 8; pi++) {
          const piNext = (pi + 1) % 8;
          const aStart = poleAngles[pi];
          const fStart = poleFluxes[pi];
          const fEnd = poleFluxes[piNext];
          const amplitude = isMeasured
            ? Math.max(0.04, (Math.abs(fStart) + Math.abs(fEnd)) / (2 * MAX_FLUX))
            : 0.5;
          const maxH = 45 * amplitude;
          const segs = 8;
          for (let k = 0; k < segs; k++) {
            const t1 = k / segs, t2 = (k + 1) / segs;
            const a1 = aStart + t1 * 45, a2 = aStart + t2 * 45;
            const r1 = rotorRadius + maxH * Math.sin(t1 * Math.PI);
            const r2 = rotorRadius + maxH * Math.sin(t2 * Math.PI);
            const pp1 = project(r1 * Math.cos((a1 * Math.PI) / 180), r1 * Math.sin((a1 * Math.PI) / 180), zMid);
            const pp2 = project(r2 * Math.cos((a2 * Math.PI) / 180), r2 * Math.sin((a2 * Math.PI) / 180), zMid);
            const tMid = (t1 + t2) / 2;
            const startNorth = fStart >= 0;
            const endNorth = fEnd >= 0;
            const r = Math.floor((startNorth ? 239 : 59) * (1 - tMid) + (endNorth ? 239 : 59) * tMid);
            const g = Math.floor((startNorth ? 68 : 130) * (1 - tMid) + (endNorth ? 68 : 130) * tMid);
            const b = Math.floor((startNorth ? 68 : 246) * (1 - tMid) + (endNorth ? 68 : 246) * tMid);
            const lineColor = isMeasured ? `rgba(${r},${g},${b},0.75)` : "rgba(57,255,20,0.25)";
            polys.push({
              type: "line", p1: pp1, p2: pp2, color: lineColor,
              width: isMeasured ? 1.8 : 1.0,
              depth: (pp1.depth + pp2.depth) / 2,
            });
          }
        }
      }
    };

    addCylinder(7, -rotorLength / 2 - 90, -rotorLength / 2 - 50, "#64748b");
    addCylinder(9, -rotorLength / 2 - 50, -rotorLength / 2 - 35, "#334155");
    addCylinder(7.5, -rotorLength / 2 - 35, -rotorLength / 2 - 10, "#475569");
    addCylinder(34, -rotorLength / 2 - 10, -rotorLength / 2, "#e2e8f0");

    const N = activeSteps.length;
    const sliceWidth = rotorLength / N;
    for (let s = 0; s < N; s++) {
      const sliceStart = -rotorLength / 2 + s * sliceWidth;
      addCylinder(rotorRadius, sliceStart, sliceStart + sliceWidth, "#1e293b", true, s);
    }

    addFluxLines();

    addCylinder(34, rotorLength / 2, rotorLength / 2 + 10, "#e2e8f0");
    addCylinder(9, rotorLength / 2 + 10, rotorLength / 2 + 25, "#334155");
    addCylinder(7, rotorLength / 2 + 25, rotorLength / 2 + 70, "#64748b");

    polys.sort((a, b) => b.depth - a.depth);
    return polys;
  }, [rotX, rotY, zoomScale, sessions, failFactor, paccoHeight, activeSteps, zOffset, isRecording, showFluxLines, MAX_FLUX, hiddenZSlices, W, H]);

  return (
    <View>
      <View
        style={[styles.canvas, { width: W, height: H }]}
        {...panResponder.panHandlers}
      >
        <Svg width={W} height={H}>
          {elements.map((el, i) => {
            if (el.type === "line") {
              return (
                <SvgLine
                  key={i}
                  x1={el.p1.x} y1={el.p1.y}
                  x2={el.p2.x} y2={el.p2.y}
                  stroke={el.color} strokeWidth={el.width}
                />
              );
            }
            const ptStr = el.pts.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ");
            return <Polygon key={i} points={ptStr} fill={el.color} stroke={el.color} strokeWidth={0.3} />;
          })}
        </Svg>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  canvas: { backgroundColor: "#0f172a", borderRadius: 12, overflow: "hidden" },
});
