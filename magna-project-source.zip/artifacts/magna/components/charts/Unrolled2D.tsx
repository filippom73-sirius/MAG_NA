import React, { useMemo } from "react";
import { ScrollView, StyleSheet, Text, View, useWindowDimensions } from "react-native";
import Svg, { Line, Path, Rect, Text as SvgText } from "react-native-svg";

import { useApp } from "@/context/AppContext";

const ANGLE_BUCKETS = 36;
const DEG_PER_BUCKET = 360 / ANGLE_BUCKETS;

function fluxColor(flux: number, maxFlux: number, isSampled: boolean): string {
  if (!isSampled) return "#39ff14";
  const ratio = Math.max(-1, Math.min(1, flux / maxFlux));
  if (ratio < 0) {
    const i = Math.floor(Math.abs(ratio) * 180);
    return `rgb(30,41,${59 + i})`;
  } else {
    const i = Math.floor(ratio * 180);
    return `rgb(${50 + i},30,30)`;
  }
}

export function Unrolled2D() {
  const {
    sessions, failFactor, paccoHeight, activeSteps,
    zOffset, isRecording, h0Slice, setH0Slice, h1Slice, setH1Slice,
    data, MAX_FLUX,
  } = useApp();

  const { width: screenWidth } = useWindowDimensions();
  const W = screenWidth - 32;
  const H = 160;
  const N = activeSteps.length;
  const sliceW = W / Math.max(1, N);

  const rects = useMemo(() => {
    const result: { x: number; y: number; w: number; h: number; color: string }[] = [];
    for (let s = 0; s < N; s++) {
      const stepZVal = activeSteps[s];
      const xStart = s * sliceW;
      const isCurrentSlice = isRecording && Math.abs(zOffset - stepZVal) < 0.1;
      const matchSession = sessions.find((sess) => Math.abs(sess.z - stepZVal) < 0.1);

      for (let b = 0; b < ANGLE_BUCKETS; b++) {
        const angleDeg = b * DEG_PER_BUCKET;
        const skewOffset = (s - N / 2) * (15 / Math.max(1, N));
        const skewedAngle = (angleDeg - skewOffset + 720) % 360;

        let flux = 0;
        let isSampled = false;
        if (isCurrentSlice) {
          flux = Math.sin(4 * (skewedAngle * Math.PI) / 180) * 1600 * failFactor;
          isSampled = true;
        } else if (matchSession) {
          const idx = Math.floor(skewedAngle) % 360;
          const pt = matchSession.data.find((d) => d.angle === idx);
          flux = pt ? pt.x : 0;
          isSampled = true;
        }

        const y = (b / ANGLE_BUCKETS) * H;
        const rectH = H / ANGLE_BUCKETS + 0.5;
        result.push({ x: xStart, y, w: sliceW + 0.5, h: rectH, color: fluxColor(flux, MAX_FLUX, isSampled) });
      }
    }
    return result;
  }, [sessions, failFactor, activeSteps, N, sliceW, zOffset, isRecording, MAX_FLUX, H]);

  const xH0 = (() => {
    const idx = activeSteps.findIndex((s) => Math.abs(s - h0Slice) < 0.1);
    return idx === -1 ? 0 : idx * sliceW + sliceW / 2;
  })();
  const xH1 = (() => {
    const idx = activeSteps.findIndex((s) => Math.abs(s - h1Slice) < 0.1);
    return idx === -1 ? 0 : idx * sliceW + sliceW / 2;
  })();

  const getWaveformPath = (zVal: number): string => {
    const isCurrentSlice = isRecording && Math.abs(zOffset - zVal) < 0.1;
    const matchSession = sessions.find((s) => Math.abs(s.z - zVal) < 0.1);
    const activeData = isCurrentSlice ? data : matchSession ? matchSession.data : [];
    if (activeData.length === 0) return "";
    const wW = W, wH = 100, centerY = wH / 2;
    const pts = activeData.map((d) => {
      const px = ((d.angle % 360) / 360) * wW;
      const py = centerY - ((d.x || 0) / MAX_FLUX) * (wH / 2.3);
      return `${px.toFixed(1)},${py.toFixed(1)}`;
    });
    return `M ${pts.join(" L ")}`;
  };

  const pathH0 = useMemo(() => getWaveformPath(h0Slice), [sessions, data, h0Slice, zOffset, isRecording, MAX_FLUX, W]);
  const pathH1 = useMemo(() => getWaveformPath(h1Slice), [sessions, data, h1Slice, zOffset, isRecording, MAX_FLUX, W]);

  const getStats = (zVal: number) => {
    const isCurrentSlice = isRecording && Math.abs(zOffset - zVal) < 0.1;
    const matchSession = sessions.find((s) => Math.abs(s.z - zVal) < 0.1);
    const d = isCurrentSlice ? data : matchSession ? matchSession.data : [];
    if (d.length === 0) return { max: 0, min: 0, sym: 100 };
    const xs = d.map((p) => p.x);
    const max = Math.max(...xs), min = Math.min(...xs);
    const sym = max !== 0 && min !== 0
      ? Math.max(10, Math.min(100, (1 - Math.abs(Math.abs(max) - Math.abs(min)) / Math.max(Math.abs(max), Math.abs(min))) * 100))
      : 100;
    return { max, min, sym };
  };

  const statsH0 = getStats(h0Slice);
  const statsH1 = getStats(h1Slice);

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Mappa Srotolata 2D</Text>
      <Svg width={W} height={H} style={{ borderRadius: 8, overflow: "hidden" }}>
        {rects.map((r, i) => (
          <Rect key={i} x={r.x} y={r.y} width={r.w} height={r.h} fill={r.color} />
        ))}
        <Line x1={xH0} y1={0} x2={xH0} y2={H} stroke="#ef4444" strokeWidth={2.5} strokeDasharray="5,3" />
        <Line x1={xH1} y1={0} x2={xH1} y2={H} stroke="#3b82f6" strokeWidth={2.5} strokeDasharray="5,3" />
        <SvgText x={xH0 + 4} y={16} fill="#ef4444" fontSize={9} fontWeight="bold">H0:{h0Slice}mm</SvgText>
        <SvgText x={xH1 + 4} y={H - 6} fill="#3b82f6" fontSize={9} fontWeight="bold">H1:{h1Slice}mm</SvgText>
      </Svg>

      <View style={styles.cursorRow}>
        <View style={styles.cursorBlock}>
          <Text style={[styles.cursorLabel, { color: "#ef4444" }]}>Cursore H0</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {activeSteps.map((s, i) => (
              <View
                key={i}
                onTouchEnd={() => setH0Slice(s)}
                style={[styles.stepChip, Math.abs(s - h0Slice) < 0.1 && { borderColor: "#ef4444", backgroundColor: "#450a0a" }]}
              >
                <Text style={{ color: "#ef4444", fontSize: 10, fontFamily: "monospace" }}>{s}mm</Text>
              </View>
            ))}
          </ScrollView>
        </View>
        <View style={styles.cursorBlock}>
          <Text style={[styles.cursorLabel, { color: "#3b82f6" }]}>Cursore H1</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {activeSteps.map((s, i) => (
              <View
                key={i}
                onTouchEnd={() => setH1Slice(s)}
                style={[styles.stepChip, Math.abs(s - h1Slice) < 0.1 && { borderColor: "#3b82f6", backgroundColor: "#172554" }]}
              >
                <Text style={{ color: "#3b82f6", fontSize: 10, fontFamily: "monospace" }}>{s}mm</Text>
              </View>
            ))}
          </ScrollView>
        </View>
      </View>

      <View style={styles.statsRow}>
        {[
          { label: "H0", color: "#ef4444", stats: statsH0, z: h0Slice },
          { label: "H1", color: "#3b82f6", stats: statsH1, z: h1Slice },
        ].map(({ label, color, stats, z }) => (
          <View key={label} style={styles.statCard}>
            <Text style={[styles.statTitle, { color }]}>{label} ({z} mm)</Text>
            <Text style={styles.statItem}>Max: <Text style={{ color: "#f1f5f9" }}>{stats.max.toFixed(0)} µT</Text></Text>
            <Text style={styles.statItem}>Min: <Text style={{ color: "#f1f5f9" }}>{stats.min.toFixed(0)} µT</Text></Text>
            <Text style={styles.statItem}>Simmetria: <Text style={{ color: stats.sym > 80 ? "#10b981" : stats.sym > 50 ? "#f59e0b" : "#ef4444" }}>{stats.sym.toFixed(0)}%</Text></Text>
          </View>
        ))}
      </View>

      {[{ path: pathH0, color: "#ef4444", label: "H0", z: h0Slice }, { path: pathH1, color: "#3b82f6", label: "H1", z: h1Slice }].map(({ path, color, label, z }) => (
        <View key={label} style={styles.waveformCard}>
          <Text style={[styles.waveLabel, { color }]}>{label} — {z} mm</Text>
          <Svg width={W - 16} height={80}>
            <Line x1={0} y1={40} x2={W - 16} y2={40} stroke="#1e293b" strokeWidth={1} strokeDasharray="4,4" />
            {[0, 45, 90, 135, 180, 225, 270, 315, 360].map((a) => (
              <Line key={a} x1={(a / 360) * (W - 16)} y1={0} x2={(a / 360) * (W - 16)} y2={80} stroke="#1e293b" strokeWidth={1} />
            ))}
            {path ? <Path d={path} fill="none" stroke={color} strokeWidth={2} /> : null}
          </Svg>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { gap: 10 },
  label: { color: "#94a3b8", fontSize: 10, fontWeight: "700", textTransform: "uppercase", letterSpacing: 1 },
  cursorRow: { flexDirection: "row", gap: 8 },
  cursorBlock: { flex: 1 },
  cursorLabel: { fontSize: 9, fontWeight: "700", textTransform: "uppercase", marginBottom: 4 },
  stepChip: { borderWidth: 1, borderColor: "#334155", borderRadius: 6, paddingHorizontal: 8, paddingVertical: 4, marginRight: 6, backgroundColor: "#0f172a" },
  statsRow: { flexDirection: "row", gap: 8 },
  statCard: { flex: 1, backgroundColor: "#1e293b", borderRadius: 10, padding: 10, borderWidth: 1, borderColor: "#334155" },
  statTitle: { fontSize: 11, fontWeight: "700", marginBottom: 4 },
  statItem: { color: "#64748b", fontSize: 10, fontFamily: "monospace" },
  waveformCard: { backgroundColor: "#0f172a", borderRadius: 10, padding: 8, borderWidth: 1, borderColor: "#1e293b" },
  waveLabel: { fontSize: 9, fontWeight: "700", fontFamily: "monospace", marginBottom: 4, textTransform: "uppercase" },
});
