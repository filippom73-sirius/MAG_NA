import React, { useMemo } from "react";
import { View, useWindowDimensions } from "react-native";
import Svg, { Circle, Line, Path, Text as SvgText } from "react-native-svg";

import { useApp } from "@/context/AppContext";

export function PolarChart() {
  const {
    data, sessions, currentAngle, zOffset, isRecording, MAX_FLUX,
    showAxisX, showAxisY, showAxisZ, showResultant,
  } = useApp();
  const { width: screenWidth } = useWindowDimensions();
  const size = Math.min(screenWidth - 32, 320);
  const center = size / 2;
  const baseR = 70;
  const maxVar = 80;

  const activeSession = sessions.find((s) => Math.abs(s.z - zOffset) < 0.1);
  const displayData = isRecording || !activeSession ? data : activeSession.data;

  const buildPolarPath = (getValue: (d: (typeof displayData)[0]) => number) => {
    if (displayData.length === 0) return "";
    const pts = displayData.map((d) => {
      const rad = ((d.angle % 360) * Math.PI) / 180;
      const r = baseR + (getValue(d) / MAX_FLUX) * maxVar;
      return `${(center + r * Math.cos(rad)).toFixed(1)},${(center + r * Math.sin(rad)).toFixed(1)}`;
    });
    return `M ${pts.join(" L ")}${displayData.length > 2 ? " Z" : ""}`;
  };

  const pathX = useMemo(() => buildPolarPath((d) => d.x || 0), [displayData, center, baseR, maxVar, MAX_FLUX]);
  const pathY = useMemo(() => buildPolarPath((d) => d.y || 0), [displayData, center, baseR, maxVar, MAX_FLUX]);
  const pathZ = useMemo(() => buildPolarPath((d) => d.z || 0), [displayData, center, baseR, maxVar, MAX_FLUX]);
  const pathR = useMemo(() => buildPolarPath((d) => Math.sqrt((d.x || 0) ** 2 + (d.y || 0) ** 2 + (d.z || 0) ** 2)), [displayData, center, baseR, maxVar, MAX_FLUX]);

  const curRad = ((currentAngle % 360) * Math.PI) / 180;
  const curX = center + (baseR + maxVar) * Math.cos(curRad);
  const curY = center + (baseR + maxVar) * Math.sin(curRad);
  const labels = [0, 45, 90, 135, 180, 225, 270, 315];

  return (
    <View style={{ alignItems: "center" }}>
      <Svg width={size} height={size}>
        <Circle cx={center} cy={center} r={baseR} stroke="#475569" strokeWidth={1} strokeDasharray="4,4" fill="none" />
        <Circle cx={center} cy={center} r={baseR + maxVar / 2} stroke="#334155" strokeWidth={1} fill="none" />
        <Circle cx={center} cy={center} r={baseR + maxVar} stroke="#334155" strokeWidth={1} fill="none" />
        <Line x1={center} y1={0} x2={center} y2={size} stroke="#334155" strokeWidth={1} />
        <Line x1={0} y1={center} x2={size} y2={center} stroke="#334155" strokeWidth={1} />
        {labels.map((angle) => {
          const r = (angle * Math.PI) / 180;
          const tx = center + (baseR + maxVar + 14) * Math.cos(r);
          const ty = center + (baseR + maxVar + 14) * Math.sin(r);
          return (
            <SvgText key={angle} x={tx} y={ty} fill="#64748b" fontSize={9} textAnchor="middle" fontFamily="monospace">{angle}°</SvgText>
          );
        })}
        {showAxisX && pathX ? <Path d={pathX} fill="none" stroke="#ef4444" strokeWidth={2} /> : null}
        {showAxisY && pathY ? <Path d={pathY} fill="none" stroke="#10b981" strokeWidth={2} /> : null}
        {showAxisZ && pathZ ? <Path d={pathZ} fill="none" stroke="#3b82f6" strokeWidth={2} /> : null}
        {showResultant && pathR ? <Path d={pathR} fill="none" stroke="#f59e0b" strokeWidth={2.5} strokeDasharray="6,3" /> : null}
        <Circle cx={center} cy={center} r={8} fill="#475569" />
        <Line x1={center} y1={center} x2={curX} y2={curY} stroke="#f59e0b" strokeWidth={2} strokeDasharray="4,4" />
      </Svg>
    </View>
  );
}
