import React, { useCallback, useEffect, useState } from "react";
import {
  Clipboard,
  Linking,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { useApp } from "@/context/AppContext";
import { useRemoteSync } from "@/hooks/useRemoteSync";

const DOMAIN = process.env.EXPO_PUBLIC_DOMAIN ?? "";
const ENCODER_URL = DOMAIN ? `https://${DOMAIN}/api/encoder` : "";
const WS_URL = DOMAIN ? `wss://${DOMAIN}/api/sync` : "";

export function RemoteSyncPanel() {
  const { isRecording, receiveCameraPulse } = useApp();
  const [copied, setCopied] = useState(false);

  const handlePulse = useCallback(
    (ts: number, idx: number) => receiveCameraPulse(ts, idx),
    [receiveCameraPulse]
  );

  const { connected, encodersOnline, pulseCount, estimatedRPM, lastError, reset } =
    useRemoteSync({
      enabled: true,
      wsUrl: WS_URL,
      onPulse: handlePulse,
    });

  useEffect(() => {
    if (!isRecording) reset();
  }, [isRecording, reset]);

  const copyUrl = () => {
    if (!ENCODER_URL) return;
    Clipboard.setString(ENCODER_URL);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  const connColor = connected
    ? "#22c55e"
    : lastError
      ? "#ef4444"
      : "#f59e0b";

  const connLabel = connected
    ? `Connesso${encodersOnline > 0 ? ` · ${encodersOnline} encoder` : ""}`
    : lastError ?? "Connessione...";

  if (!DOMAIN) {
    return (
      <View style={styles.card}>
        <Text style={styles.title}>📡  Encoder Remoto</Text>
        <Text style={styles.hint}>
          EXPO_PUBLIC_DOMAIN non configurato — controlla le variabili d'ambiente.
        </Text>
      </View>
    );
  }

  return (
    <View style={styles.card}>
      {/* Header */}
      <View style={styles.headerRow}>
        <Text style={styles.title}>📡  Encoder Remoto — WiFi Hotspot</Text>
        <View style={[styles.connBadge, { borderColor: connColor }]}>
          <View style={[styles.connDot, { backgroundColor: connColor }]} />
          <Text style={[styles.connText, { color: connColor }]}>{connLabel}</Text>
        </View>
      </View>

      {/* Encoder URL */}
      <View style={styles.urlRow}>
        <View style={styles.urlBox}>
          <Text style={styles.urlLabel}>APRI SUL SECONDO TELEFONO (browser)</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <Text style={styles.urlText}>{ENCODER_URL}</Text>
          </ScrollView>
        </View>
        <Pressable onPress={copyUrl} style={styles.btnCopy}>
          <Text style={styles.btnCopyText}>{copied ? "✓" : "Copia"}</Text>
        </Pressable>
      </View>

      {/* Stats row */}
      <View style={styles.statsRow}>
        <View style={styles.statBox}>
          <Text style={styles.statLabel}>ENCODER</Text>
          <Text
            style={[
              styles.statValue,
              { color: encodersOnline > 0 ? "#22c55e" : "#475569" },
            ]}
          >
            {encodersOnline}
          </Text>
        </View>
        <View style={styles.statBox}>
          <Text style={styles.statLabel}>IMPULSI</Text>
          <Text style={styles.statValue}>{pulseCount}</Text>
        </View>
        <View style={styles.statBox}>
          <Text style={styles.statLabel}>RPM REMOTO</Text>
          <Text style={[styles.statValue, { color: "#22c55e" }]}>
            {estimatedRPM !== null ? estimatedRPM.toFixed(2) : "--.-"}
          </Text>
        </View>
      </View>

      {/* Status message */}
      {!connected ? (
        <Text style={styles.hint}>
          ⚠  Assicurati che entrambi i telefoni siano connessi alla stessa rete
          (hotspot di questo telefono)
        </Text>
      ) : encodersOnline === 0 ? (
        <Text style={styles.hint}>
          📱  Apri l'URL sopra nel browser del secondo telefono → calibra SCURO /
          BIANCO → il rilevamento parte automaticamente
        </Text>
      ) : (
        <View style={styles.readyBadge}>
          <Text style={styles.readyText}>
            ✓  Encoder connesso — premi AVVIA per iniziare la misura
          </Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#070f1c",
    borderTopWidth: 1,
    borderTopColor: "#1e3a5f",
    paddingHorizontal: 12,
    paddingTop: 10,
    paddingBottom: 12,
    gap: 8,
  },
  headerRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    flexWrap: "wrap",
    gap: 6,
  },
  title: {
    color: "#60a5fa",
    fontSize: 11,
    fontWeight: "800",
    letterSpacing: 0.8,
  },
  connBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    borderWidth: 1,
    borderRadius: 6,
    paddingHorizontal: 7,
    paddingVertical: 3,
  },
  connDot: { width: 7, height: 7, borderRadius: 4 },
  connText: { fontSize: 10, fontWeight: "700" },

  urlRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: "#0a1628",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#1e3a5f",
    paddingHorizontal: 10,
    paddingVertical: 8,
  },
  urlBox: { flex: 1, gap: 2 },
  urlLabel: {
    color: "#475569",
    fontSize: 7,
    fontWeight: "800",
    letterSpacing: 0.5,
  },
  urlText: {
    color: "#93c5fd",
    fontSize: 11,
    fontFamily: "monospace",
    fontWeight: "600",
  },
  btnCopy: {
    backgroundColor: "#1e3a8a",
    borderRadius: 7,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: "#3b82f6",
  },
  btnCopyText: { color: "#93c5fd", fontSize: 11, fontWeight: "800" },

  statsRow: { flexDirection: "row", gap: 6 },
  statBox: {
    flex: 1,
    backgroundColor: "#0f172a",
    borderRadius: 8,
    paddingVertical: 6,
    paddingHorizontal: 6,
    alignItems: "center",
    gap: 2,
  },
  statLabel: {
    color: "#475569",
    fontSize: 7,
    fontWeight: "800",
    letterSpacing: 0.5,
  },
  statValue: {
    color: "#f8fafc",
    fontSize: 14,
    fontWeight: "800",
    fontFamily: "monospace",
  },

  hint: {
    color: "#64748b",
    fontSize: 10,
    fontStyle: "italic",
    lineHeight: 15,
  },
  readyBadge: {
    backgroundColor: "#052e16",
    borderWidth: 1,
    borderColor: "#166534",
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 7,
    alignItems: "center",
  },
  readyText: { color: "#4ade80", fontSize: 11, fontWeight: "700" },
});
